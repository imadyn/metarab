/**
 * Data Transfer Objects.
 */
package ac.fidoteam.alkhalil.service.dto;

/**
 * Service layer beans.
 */
package ac.fidoteam.alkhalil.service;

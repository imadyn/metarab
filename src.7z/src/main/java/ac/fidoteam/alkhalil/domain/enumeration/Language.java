package ac.fidoteam.alkhalil.domain.enumeration;

/**
 * The Language enumeration.
 */
public enum Language {
    FRENCH, ENGLISH, SPANISH, ARABIC
}

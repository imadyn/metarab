package ac.fidoteam.alkhalil.domain.enumeration;

/**
 * The Transform enumeration.
 */
public enum Transform {
    IDENTITE, KHABN, WAKS, IDMAR, TAY, KABD, AKLE, ASBE, KAF, KHABL, KHAZL, CHAKL, NAKS, TATHBIL, TARFIL, TASBIGH, HATHF, KATF, KATAE, BATR, KASR, HATHATH, SALAM, WAKF, KACHF, KHARM, TACHEIT, KABL
}

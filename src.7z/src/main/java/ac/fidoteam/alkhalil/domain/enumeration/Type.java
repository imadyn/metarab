package ac.fidoteam.alkhalil.domain.enumeration;

/**
 * The Type enumeration.
 */
public enum Type {
    HACHW, AROUD, DARB, RYTHME, MESURE
}

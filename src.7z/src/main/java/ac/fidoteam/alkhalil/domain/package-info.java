/**
 * JPA domain objects.
 */
package ac.fidoteam.alkhalil.domain;

package ac.fidoteam.alkhalil.domain.enumeration;

/**
 * The Style enumeration.
 */
public enum Style {
    TAME, WAFI, MAJZOE, MACHTOR, MANHOK
}

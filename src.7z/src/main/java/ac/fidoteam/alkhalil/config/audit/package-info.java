/**
 * Audit specific code.
 */
package ac.fidoteam.alkhalil.config.audit;

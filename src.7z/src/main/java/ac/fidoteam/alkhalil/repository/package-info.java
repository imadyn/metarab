/**
 * Spring Data JPA repositories.
 */
package ac.fidoteam.alkhalil.repository;

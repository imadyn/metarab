/**
 * Spring Data Elasticsearch repositories.
 */
package ac.fidoteam.alkhalil.repository.search;

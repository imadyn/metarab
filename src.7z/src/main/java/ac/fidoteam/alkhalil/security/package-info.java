/**
 * Spring Security configuration.
 */
package ac.fidoteam.alkhalil.security;

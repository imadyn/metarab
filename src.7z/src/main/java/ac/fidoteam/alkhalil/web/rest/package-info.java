/**
 * Spring MVC REST controllers.
 */
package ac.fidoteam.alkhalil.web.rest;

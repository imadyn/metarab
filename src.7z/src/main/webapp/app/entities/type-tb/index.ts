export * from './type-tb.service';
export * from './type-tb-update.component';
export * from './type-tb-delete-dialog.component';
export * from './type-tb-detail.component';
export * from './type-tb.component';
export * from './type-tb.route';
